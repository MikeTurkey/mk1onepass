'''
SHA3-256(/Volumes/thder_data/home_mike/svnwork/current/mk1onepass/head/public/script/mk1onepass.py)= 5837047f3d4f0d19da906bb4b971254d82246918608ca4d40e84a1bad09241e8
SHA3-256(/Volumes/thder_data/home_mike/svnwork/current/mk1onepass/head/public/pypi/mk1onepass/__init__.py)= 7d881727c533aded9702e43a3834331f92b631619b31f20fb26bd78e439fede4
SHA3-256(/Volumes/thder_data/home_mike/svnwork/current/mk1onepass/head/public/pypi/mk1onepass/__main__.py)= 677776840335531583f3f4e5af239b64665dff74218f7b4e749ee942ac344920
'''
